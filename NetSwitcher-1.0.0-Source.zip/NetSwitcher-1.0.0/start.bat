@echo off
rem NetSwitcher launcher: elevates, then starts the built-in web UI.
setlocal
cd /d "%~dp0"

where python >nul 2>&1
if errorlevel 1 goto no_python

rem 启停网卡需要管理员权限，没提权就重新用管理员身份拉起自己
net session >nul 2>&1
if errorlevel 1 (
  echo Requesting administrator privileges...
  powershell -NoProfile -Command "Start-Process -Verb RunAs -FilePath '%~f0'"
  exit /b
)

echo Starting NetSwitcher kernel on 127.0.0.1 ...
python -m netswitcher serve --open
echo.
echo Kernel exited.
pause
exit /b

:no_python
echo Python 3.11+ was not found in PATH.
echo Install it from https://www.python.org/downloads/ and tick "Add python.exe to PATH".
pause
exit /b
